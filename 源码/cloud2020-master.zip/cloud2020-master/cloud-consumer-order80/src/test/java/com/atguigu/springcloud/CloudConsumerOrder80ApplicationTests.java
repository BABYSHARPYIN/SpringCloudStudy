package com.atguigu.springcloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConsumerOrder80ApplicationTests {

    @Test
    void contextLoads() {
    }

}
